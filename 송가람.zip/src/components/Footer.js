import { BotBar } from "../styles/footerstyle";

const Footer = () => {
  return <BotBar>홍길동</BotBar>;
};

export default Footer;
