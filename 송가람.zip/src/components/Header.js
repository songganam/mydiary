import { TopBar } from "../styles/headerstyle";

const Header = props => {
  return (
    <TopBar>
      <button>
        <img src="images/bt_list.svg" />
      </button>
      <Header>{props.children}</Header>
      <button>
        <img src="images/bt_login.svg" />
      </button>
    </TopBar>
  );
};

export default Header;
