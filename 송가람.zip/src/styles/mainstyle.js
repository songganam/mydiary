import styled from "@emotion/styled";

export const Contents = styled.main`
  width: 100%;
  min-height: 500px;
`;
