import Index from "./pages/Index";
import Intro from "./pages/Intro";
import DiaryAdd from "./pages/diary/DiaryAdd";
import DiaryEdit from "./pages/diary/DiaryEdit";
import DiaryIndex from "./pages/diary/Index";
import "./styles/App.css";

function App() {
  return (
    <div className="layout">
      <div className="wrap">
        <Intro></Intro>
        <Index></Index>
        {/*<DiaryIndex></DiaryIndex>
        <DiaryAdd></DiaryAdd>
        <DiaryEdit></DiaryEdit> */}
      </div>
    </div>
  );
}

export default App;
