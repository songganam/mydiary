import React from "react";
import Main from "../components/Main";

const Intro = () => {
  return (
    <Main>
      <h1 style={{ textAlign: "center" }}>인트로</h1>
    </Main>
  );
};

export default Intro;
